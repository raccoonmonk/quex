#include "stdio.h"
#include "unistd.h"
#include "stdlib.h"
#include "common_types.h"
#include "osapi.h"
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <signal.h>
#include <dlfcn.h>
#ifdef OS_INCLUDE_MODULE_LOADER
extern int OS_InterruptSafeLock(pthread_mutex_t *lock, sigset_t *set, sigset_t *previous);
extern void OS_InterruptSafeUnlock(pthread_mutex_t *lock, sigset_t *previous);
typedef struct
{
   int free;
   cpuaddr entry_point;
   void * host_module_id;
   char filename[OS_MAX_PATH_LEN];
   char name[OS_MAX_API_NAME];
} OS_module_internal_record_t;
OS_module_internal_record_t OS_module_table[OS_MAX_MODULES];
pthread_mutex_t OS_module_table_mut;
int32 OS_ModuleTableInit ( void )
{
   int i;
   int return_code;
   for(i = 0; i < OS_MAX_MODULES; i++)
   {
      OS_module_table[i].free = TRUE;
      OS_module_table[i].entry_point = 0;
      OS_module_table[i].host_module_id = 0;
      strcpy(OS_module_table[i].name,"");
      strcpy(OS_module_table[i].filename,"");
   }
   return_code = pthread_mutex_init((pthread_mutex_t *) & OS_module_table_mut,NULL);
   if ( return_code == 0)
   {
      return(OS_SUCCESS);
   }
   else
   {
      return(OS_ERROR);
   }
}
int32 OS_SymbolLookup( cpuaddr *SymbolAddress, const char *SymbolName )
{
   const char *dlError;
   void *Function;
   dlerror();
   if (( SymbolAddress == NULL ) || ( SymbolName == NULL ))
   {
      return(OS_INVALID_POINTER);
   }
   Function = dlsym((void *)0, SymbolName);
   dlError = dlerror();
   if( dlError )
   {
      return(OS_ERROR);
   }
   *SymbolAddress = (cpuaddr)Function;
   return(OS_SUCCESS);
}
int32 OS_SymbolTableDump ( const char *filename, uint32 SizeLimit )
{
   return(OS_ERR_NOT_IMPLEMENTED);
}
int32 OS_ModuleLoad ( uint32 *module_id, const char *module_name, const char *filename )
{
   int i;
   uint32 possible_moduleid;
   char translated_path[OS_MAX_LOCAL_PATH_LEN];
   int32 return_code;
   void *function_lib;
   const char *dl_error;
   sigset_t previous;
   sigset_t mask;
   if (( filename == NULL ) || (module_id == NULL ) || (module_name == NULL))
   {
      return(OS_INVALID_POINTER);
   }
   OS_InterruptSafeLock(&OS_module_table_mut, &mask, &previous);
   for( possible_moduleid = 0; possible_moduleid < OS_MAX_MODULES; possible_moduleid++)
   {
       if (OS_module_table[possible_moduleid].free == TRUE)
       {
           break;
       }
   }
   if( possible_moduleid >= OS_MAX_MODULES || OS_module_table[possible_moduleid].free != TRUE)
   {
       OS_InterruptSafeUnlock(&OS_module_table_mut, &previous);
       return OS_ERR_NO_FREE_IDS;
   }
   for (i = 0; i < OS_MAX_MODULES; i++)
   {
       if ((OS_module_table[i].free == FALSE) &&
          ( strcmp((char*) module_name, OS_module_table[i].name) == 0))
       {
           OS_InterruptSafeUnlock(&OS_module_table_mut, &previous);
           return OS_ERR_NAME_TAKEN;
       }
   }
   OS_module_table[possible_moduleid].free = FALSE ;
   OS_InterruptSafeUnlock(&OS_module_table_mut, &previous);
   return_code = OS_TranslatePath((const char *)filename, (char *)translated_path);
   if ( return_code != OS_SUCCESS )
   {
      OS_module_table[possible_moduleid].free = TRUE;
      return(return_code);
   }
   function_lib = dlopen(translated_path, RTLD_LAZY | RTLD_GLOBAL);
   dl_error = dlerror();
   if( dl_error )
   {
      OS_module_table[possible_moduleid].free = TRUE;
      return(OS_ERROR);
   }
   OS_module_table[possible_moduleid].entry_point = 0;
   OS_module_table[possible_moduleid].host_module_id = function_lib;
   strncpy(OS_module_table[possible_moduleid].filename , filename, OS_MAX_PATH_LEN);
   strncpy(OS_module_table[possible_moduleid].name , module_name, OS_MAX_API_NAME);
   *module_id = possible_moduleid;
   return(OS_SUCCESS);
}
int32 OS_ModuleUnload ( uint32 module_id )
{
   const char *dlError;
   if ( module_id >= OS_MAX_MODULES || OS_module_table[module_id].free == TRUE )
   {
      return(OS_ERR_INVALID_ID);
   }
   dlclose((void *)OS_module_table[module_id].host_module_id);
   dlError = dlerror();
   if( dlError )
   {
      OS_module_table[module_id].free = TRUE;
      return(OS_ERROR);
   }
   OS_module_table[module_id].free = TRUE;
   return(OS_SUCCESS);
}
int32 OS_ModuleInfo ( uint32 module_id, OS_module_prop_t *module_info )
{
   if ( module_info == 0 )
   {
      return(OS_INVALID_POINTER);
   }
   if ( module_id >= OS_MAX_MODULES || OS_module_table[module_id].free == TRUE )
   {
      return(OS_ERR_INVALID_ID);
   }
   module_info->entry_point = OS_module_table[module_id].entry_point;
   module_info->host_module_id = (uint32)OS_module_table[module_id].host_module_id;
   strncpy(module_info->filename, OS_module_table[module_id].filename , OS_MAX_PATH_LEN);
   strncpy(module_info->name, OS_module_table[module_id].name, OS_MAX_API_NAME);
   module_info->addr.valid = FALSE;
   module_info->addr.code_address = 0;
   module_info->addr.code_size = 0;
   module_info->addr.data_address = 0;
   module_info->addr.data_size = 0;
   module_info->addr.bss_address = 0;
   module_info->addr.bss_size = 0;
   module_info->addr.flags = 0;
   return(OS_SUCCESS);
}
#endif
