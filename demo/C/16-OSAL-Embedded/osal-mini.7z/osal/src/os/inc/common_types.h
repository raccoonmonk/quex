#ifndef _common_types_
#define _common_types_ 
#ifdef __cplusplus
   extern "C" {
#endif
#define CompileTimeAssert(Condition,Message) typedef char Message[(Condition) ? 1 : -1]
#if defined (__GNUC__) && !defined(OSAPI_NO_SPECIAL_ATTRIBS)
   #define _EXTENSION_ __extension__
   #define OS_PACK __attribute__ ((packed))
   #define OS_ALIGN(n) __attribute__((aligned(n)))
   #define OS_USED __attribute__((used))
   #define OS_PRINTF(n,m) __attribute__ ((format (printf, n, m)))
#else
   #define _EXTENSION_
   #define OS_PACK
   #define OS_ALIGN(n)
   #define OS_USED
   #define OS_PRINTF(n,m)
#endif
#if defined(_HAVE_STDINT_)
#include <stdint.h>
#include <stddef.h>
  typedef uint8_t osalbool;
  typedef int8_t int8;
  typedef int16_t int16;
  typedef int32_t int32;
  typedef int64_t int64;
  typedef uint8_t uint8;
  typedef uint16_t uint16;
  typedef uint32_t uint32;
  typedef uint64_t uint64;
  typedef intptr_t intptr;
  typedef uintptr_t cpuaddr;
  typedef size_t cpusize;
  typedef ptrdiff_t cpudiff;
#elif defined(_ix86_) || defined (__i386__)
  #undef _STRUCT_HIGH_BIT_FIRST_
  #define _STRUCT_LOW_BIT_FIRST_
  typedef unsigned char osalbool;
  typedef signed char int8;
  typedef short int int16;
  typedef long int int32;
 _EXTENSION_ typedef long long int int64;
  typedef unsigned char uint8;
  typedef unsigned short int uint16;
  typedef unsigned long int uint32;
  _EXTENSION_ typedef unsigned long long int uint64;
  typedef unsigned long int cpuaddr;
  typedef unsigned long int cpusize;
  typedef long int cpudiff;
#elif defined (_ix64_) || defined (__x86_64__)
  #undef _STRUCT_HIGH_BIT_FIRST_
  #define _STRUCT_LOW_BIT_FIRST_
  typedef unsigned char osalbool;
  typedef signed char int8;
  typedef short int int16;
  typedef int int32;
  typedef long int int64;
  typedef unsigned char uint8;
  typedef unsigned short int uint16;
  typedef unsigned int uint32;
  typedef unsigned long int uint64;
  typedef unsigned long int cpuaddr;
  typedef unsigned long int cpusize;
  typedef long int cpudiff;
#elif defined(__PPC__) || defined (__ppc__)
   #define _STRUCT_HIGH_BIT_FIRST_
   #undef _STRUCT_LOW_BIT_FIRST_
   typedef unsigned char osalbool;
   typedef signed char int8;
   typedef short int int16;
   typedef long int int32;
   _EXTENSION_ typedef long long int int64;
   typedef unsigned char uint8;
   typedef unsigned short int uint16;
   typedef unsigned long int uint32;
   _EXTENSION_ typedef unsigned long long int uint64;
   typedef unsigned long int cpuaddr;
   typedef unsigned long int cpusize;
   typedef long int cpudiff;
#elif defined(_m68k_) || defined(__m68k__)
   #define _STRUCT_HIGH_BIT_FIRST_
   #undef _STRUCT_LOW_BIT_FIRST_
   typedef unsigned char osalbool;
   typedef signed char int8;
   typedef short int int16;
   typedef long int int32;
   _EXTENSION_ typedef long long int int64;
   typedef unsigned char uint8;
   typedef unsigned short int uint16;
   typedef unsigned long int uint32;
   _EXTENSION_ typedef unsigned long long int uint64;
   typedef unsigned long int cpuaddr;
   typedef unsigned long int cpusize;
   typedef long int cpudiff;
#elif defined (__ARM__) || defined(__arm__)
  #undef _STRUCT_HIGH_BIT_FIRST_
  #define _STRUCT_LOW_BIT_FIRST_
  typedef unsigned char osalbool;
  typedef signed char int8;
  typedef short int int16;
  typedef long int int32;
  _EXTENSION_ typedef long long int int64;
  typedef unsigned char uint8;
  typedef unsigned short int uint16;
  typedef unsigned long int uint32;
  _EXTENSION_ typedef unsigned long long int uint64;
  typedef unsigned long int cpuaddr;
  typedef unsigned long int cpusize;
  typedef long int cpudiff;
#elif defined(__SPARC__) || defined (_sparc_)
   #define _STRUCT_HIGH_BIT_FIRST_
   #undef _STRUCT_LOW_BIT_FIRST_
   typedef unsigned char osalbool;
   typedef signed char int8;
   typedef short int int16;
   typedef long int int32;
   _EXTENSION_ typedef long long int int64;
   typedef unsigned char uint8;
   typedef unsigned short int uint16;
   typedef unsigned long int uint32;
   _EXTENSION_ typedef unsigned long long int uint64;
   typedef unsigned long int cpuaddr;
   typedef unsigned long int cpusize;
   typedef long int cpudiff;
#else
   #error undefined processor
#endif
#if (!defined(_USING_RTEMS_INCLUDES_) || !defined(RTEMS_DEPRECATED_TYPES))
  typedef osalbool boolean;
#endif
#ifndef NULL
   #define NULL ((void *) 0)
#endif
#ifndef TRUE
   #define TRUE (1)
#endif
#ifndef FALSE
   #define FALSE (0)
#endif
CompileTimeAssert(sizeof(uint8)==1, TypeUint8WrongSize);
CompileTimeAssert(sizeof(uint16)==2, TypeUint16WrongSize);
CompileTimeAssert(sizeof(uint32)==4, TypeUint32WrongSize);
CompileTimeAssert(sizeof(uint64)==8, TypeUint64WrongSize);
CompileTimeAssert(sizeof(int8)==1, Typeint8WrongSize);
CompileTimeAssert(sizeof(int16)==2, Typeint16WrongSize);
CompileTimeAssert(sizeof(int32)==4, Typeint32WrongSize);
CompileTimeAssert(sizeof(int64)==8, Typeint64WrongSize);
CompileTimeAssert(sizeof(cpuaddr) >= sizeof(void *), TypePtrWrongSize);
#if !defined(SOFTWARE_BIG_BIT_ORDER) && !defined(SOFTWARE_LITTLE_BIT_ORDER)
#if defined(__BYTE_ORDER) && __BYTE_ORDER == __BIG_ENDIAN || \
    defined(__BIG_ENDIAN__) || \
    defined(__ARMEB__) || \
    defined(__THUMBEB__) || \
    defined(__AARCH64EB__) || \
    defined(_MIBSEB) || defined(__MIBSEB) || defined(__MIBSEB__)
#define SOFTWARE_BIG_BIT_ORDER 
#elif defined(__BYTE_ORDER) && __BYTE_ORDER == __LITTLE_ENDIAN || \
    defined(__LITTLE_ENDIAN__) || \
    defined(__ARMEL__) || \
    defined(__THUMBEL__) || \
    defined(__AARCH64EL__) || \
    defined(_MIPSEL) || defined(__MIPSEL) || defined(__MIPSEL__)
#define SOFTWARE_LITTLE_BIT_ORDER 
#endif
#endif
#ifdef __cplusplus
   }
#endif
#endif
