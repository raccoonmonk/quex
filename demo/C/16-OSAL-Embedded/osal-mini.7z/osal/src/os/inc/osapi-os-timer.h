#ifndef _osapi_timer_
#define _osapi_timer_ 
typedef void (*OS_TimerCallback_t)(uint32 timer_id);
typedef int32 (*OS_TimerSync_t)(uint32 timer_id);
typedef struct
{
   char name[OS_MAX_API_NAME];
   uint32 creator;
   uint32 start_time;
   uint32 interval_time;
   uint32 accuracy;
} OS_timer_prop_t;
typedef struct
{
    char name[OS_MAX_API_NAME];
    uint32 creator;
    uint32 interval_time;
    uint32 accuracy;
} OS_timebase_prop_t;
int32 OS_TimerAPIInit (void);
int32 OS_TimeBaseCreate (uint32 *timer_id, const char *timebase_name, OS_TimerSync_t external_sync);
int32 OS_TimeBaseSet (uint32 timer_id, uint32 start_time, uint32 interval_time);
int32 OS_TimeBaseDelete (uint32 timer_id);
int32 OS_TimeBaseGetIdByName (uint32 *timer_id, const char *timebase_name);
int32 OS_TimerCreate (uint32 *timer_id, const char *timer_name, uint32 *clock_accuracy, OS_TimerCallback_t callback_ptr);
int32 OS_TimerAdd (uint32 *timer_id, const char *timer_name, uint32 timebase_id, OS_ArgCallback_t callback_ptr, void *callback_arg);
int32 OS_TimerSet (uint32 timer_id, uint32 start_time, uint32 interval_time);
int32 OS_TimerDelete (uint32 timer_id);
int32 OS_TimerGetIdByName (uint32 *timer_id, const char *timer_name);
int32 OS_TimerGetInfo (uint32 timer_id, OS_timer_prop_t *timer_prop);
#endif
