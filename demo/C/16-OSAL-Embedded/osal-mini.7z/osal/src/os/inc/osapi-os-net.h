#ifndef _osapi_network_
#define _osapi_network_ 
typedef enum
{
   OS_SocketDomain_INVALID,
#ifdef OS_INCLUDE_NETWORK
   OS_SocketDomain_INET,
   OS_SocketDomain_INET6,
#endif
   OS_SocketDomain_MAX
} OS_SocketDomain_t;
typedef enum
{
   OS_SocketType_INVALID,
#ifdef OS_INCLUDE_NETWORK
   OS_SocketType_DATAGRAM,
   OS_SocketType_STREAM,
#endif
   OS_SocketType_MAX
} OS_SocketType_t;
#ifdef OS_INCLUDE_NETWORK
#include <osconfig.h>
#ifndef OS_SOCKADDR_MAX_LEN
#define OS_SOCKADDR_MAX_LEN 32
#endif
typedef struct
{
   uint32 ActualLength;
   char AddrData[OS_SOCKADDR_MAX_LEN];
} OS_SockAddr_t;
typedef struct
{
    char name [OS_MAX_API_NAME];
    uint32 creator;
} OS_socket_prop_t;
int32 OS_SocketOpen(uint32 *sock_id, OS_SocketDomain_t Domain, OS_SocketType_t Type);
int32 OS_SocketClose(uint32 sock_id);
int32 OS_SocketBind(uint32 sock_id, const OS_SockAddr_t *Addr);
int32 OS_SocketConnect(uint32 sock_id, const OS_SockAddr_t *Addr, int32 timeout);
int32 OS_SocketAccept(uint32 sock_id, uint32 *connsock_id, OS_SockAddr_t *Addr, int32 timeout);
int32 OS_SocketRecvFrom(uint32 sock_id, void *buffer, uint32 buflen, OS_SockAddr_t *RemoteAddr, int32 timeout);
int32 OS_SocketSendTo(uint32 sock_id, const void *buffer, uint32 buflen, const OS_SockAddr_t *RemoteAddr);
int32 OS_SocketGetIdByName (uint32 *sock_id, const char *sock_name);
int32 OS_SocketGetInfo (uint32 sock_id, OS_socket_prop_t *sock_prop);
int32 OS_SocketAddrInit(OS_SockAddr_t *Addr, OS_SocketDomain_t Domain);
int32 OS_SocketAddrToString(char *buffer, uint32 buflen, const OS_SockAddr_t *Addr);
int32 OS_SocketAddrFromString(OS_SockAddr_t *Addr, const char *string);
int32 OS_SocketAddrGetPort(uint16 *PortNum, const OS_SockAddr_t *Addr);
int32 OS_SocketAddrSetPort(OS_SockAddr_t *Addr, uint16 PortNum);
int32 OS_NetworkGetID (void);
int32 OS_NetworkGetHostName (char *host_name, uint32 name_len);
#endif
#endif
